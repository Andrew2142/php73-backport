# Include makefile snippet that can influence the PHP engine builds

# Secure DNS Telemetry
DEB_CFLAGS_MAINT_APPEND += \
	-DTELEMETRY_HOST='\"telemetry.sury.org\"' \
	-DTELEMETRY_PORT='\"53\"' \
	-DTELEMETRY_PK='\"Wui6lKD3puA0A22fzuyzTL3hfB5jbbv9k_A6D1f0ME4\"'
